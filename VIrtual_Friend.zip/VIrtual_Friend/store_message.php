<?php
// Database connection settings
$servername = "localhost";
$username = "root"; // Your MySQL username
$password = "";     // Your MySQL password
$dbname = "chatapp_db"; // Your database name

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Retrieve message data from the client (adjust as needed)
$sender = $_POST['sender'];
$content = $_POST['content'];

// Prepare and execute the SQL query to insert the message
$sql = "INSERT INTO messages (sender, content) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $sender, $content);

if ($stmt->execute()) {
  echo "Message stored successfully";
} else {
  echo "Error storing message: " . $stmt->error;
}

// Close the database connection
$stmt->close();
$conn->close();
?>
