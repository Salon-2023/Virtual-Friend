<?php
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "chatapp_db"; // Replace with your database name

// Create a database connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve chat history (replace 'your_table' with your actual table name)
$sql = "SELECT sender, content FROM messages ORDER BY timestamp ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Define an array to store chat history
    $chatHistory = array();

    // Fetch and format chat history
    while ($row = $result->fetch_assoc()) {
        $message = array(
            "sender" => $row["sender"],
            "content" => $row["content"]
        );
        $chatHistory[] = $message;
    }

    // Return chat history as JSON
    echo json_encode($chatHistory);
} else {
    // No chat history found
    echo json_encode(array());
}

// Close the database connection
$conn->close();
?>
