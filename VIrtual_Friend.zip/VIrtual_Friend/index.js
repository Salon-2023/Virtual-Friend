// Function to send user message and receive chatbot response
function sendMessage() {
    var userInput = document.getElementById("user-input");
    var userMessage = userInput.value;

    if (userMessage !== "") {
        var chatbotMessages = document.getElementById("chatbot-messages");
        var userDiv = document.createElement("div");
        var chatbotDiv = document.createElement("div");

        userDiv.innerHTML = `<p class="user-icon"><i class="fas fa-user"></i> You: ${userMessage}</p>`;
        chatbotDiv.innerHTML = `<p class="chatbot-icon"><i class="fas fa-robot"></i> Chatbot: Loading response...</p>`;

        userDiv.classList.add("chatbot-message");
        chatbotDiv.classList.add("chatbot-message");

        chatbotMessages.appendChild(userDiv);
        chatbotMessages.appendChild(chatbotDiv);

        userInput.value = "";

        generateResponse(userMessage).then(function (response) {
            chatbotDiv.innerHTML = `<p class="chatbot-icon"><i class="fas fa-robot"></i> Chatbot: ${response}</p>`;
        }).catch(function (error) {
            chatbotDiv.innerHTML = `<p class="chatbot-icon"><i class="fas fa-robot"></i> Chatbot: Oops! Something went wrong while fetching the response.</p>`;
        });
    }
}

// Function to fetch response from the backend
async function generateResponse(userMessage) {
    const response = await fetch('/generate-response', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'user_message=' + encodeURIComponent(userMessage)
    });

    if (!response.ok) {
        throw new Error('Error fetching response from server');
    }

    const responseData = await response.json();
    return responseData.response;
}

// Function to handle user logout
function logout() {
    var chatbotContainer = document.querySelector(".chatbot-container");
    var logoutButton = document.querySelector(".logout-button");
    chatbotContainer.style.display = "none";
    logoutButton.style.display = "none";
    alert("Successfully logged out!");
    window.location.href = "/HTML/home.html"; // Replace with your home page URL
}
