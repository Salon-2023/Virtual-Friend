<?php
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Database connection details
$host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "users";

// Create connection
$conn = new mysqli($host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve submitted form data
    $regusername = $_POST['reg_username'];
    $regpassword = $_POST['reg_password'];

    // Input validation
    if (!filter_var($regusername, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

 // Password complexity validation
if (strlen($regpassword) < 8 ||
!preg_match('/[A-Z]/', $regpassword) ||
!preg_match('/[0-9]/', $regpassword) ||
!preg_match('/[^A-Za-z0-9]/', $regpassword)) {
$errorMessage = "Password must meet the following criteria:<br>";
$errorMessage .= "- At least 8 characters long.<br>";
$errorMessage .= "- At least one uppercase letter.<br>";
$errorMessage .= "- At least one digit.<br>";
$errorMessage .= "- At least one special symbol (non-alphanumeric character).";
die($errorMessage);
}


    // Sanitize the input data to prevent SQL injection
    $regusername = $conn->real_escape_string($regusername);

    // Check if the email already exists
    $checkEmailQuery = "SELECT * FROM users WHERE email = '$regusername'";
    $result = $conn->query($checkEmailQuery);

    if ($result->num_rows > 0) {
        // Email already exists
        echo "User with this email already exists. Please log in.";
        header("Location: login.html");
        exit;
    } else {
        // Hash the password using bcrypt
        $hashedPassword = password_hash($regpassword, PASSWORD_BCRYPT);

        // Perform SQL query to insert the user into the database
        $sql = "INSERT INTO users (email, password, activation_token) VALUES ('$regusername', '$hashedPassword', '')";

        if ($conn->query($sql) === TRUE) {
            // Registration successful
            // Generate activation token
            $activationToken = bin2hex(random_bytes(32));

            // Store activation token in the database
            $updateTokenSql = "UPDATE users SET activation_token = '$activationToken' WHERE email = '$regusername'";
            if ($conn->query($updateTokenSql) === TRUE) {
                // Send the activation email
                $mail = new PHPMailer();
                try {
                    // SMTP configuration
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';  // Specify your SMTP server
                    $mail->SMTPAuth   = true;               // Enable SMTP authentication
                    $mail->Username   = 'salonthapa511@gmail.com'; // SMTP username
                    $mail->Password   = 'pxfifsbmejregmwo'; // SMTP password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
                    $mail->Port       = 587;  // TCP port to connect to

                    $mail->setFrom('salonthapa511@gmail.com', 'Salon Thapa'); // Sender email and name
                    $mail->addAddress($regusername); // Recipient email

                    $mail->isHTML(true);
                    $mail->Subject = 'Activate your account';

                    $mail->Body = <<<EOT
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome to Your Virtual Friend</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            height: 100vh;
            background-size: cover;
            background-position: center;
        }
        .header {
            color: #f29d1f;
            text-align: center;
            padding: 20px;
        }
        .logo-container {
            text-align: center;
        }
        .logo {
            width: 150px;
            height: 150px;
            border-radius: 50%; /* Make the logo circular */
            float: left;
        }
        .content {
            padding: 20px;
            color: aliceblue;
        }
        .footer {
            color: #f29d1f;
            text-align: center;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo-container">
                <img src="chatbot.jpg" alt="Your Virtual Friend Logo" class="logo">
            </div>
            <h1>Welcome to Your Virtual Friend</h1>
        </div>
        <div class="content">
            <p>Hello,</p>
            <p>We are delighted to welcome you to Your Virtual Friend, your personalized virtual companion.</p>
            <p>Your account has been successfully created, and you are now part of our innovative community.</p>
            <p>If you have any questions or need assistance, please feel free to reach out to our support team at <a href="mailto:support@yourvirtualfriend.com">support@yourvirtualfriend.com</a>.</p>
            <p>Thank you for choosing Your Virtual Friend. We look forward to assisting you on your journey.</p>
            <p>Best regards,<br> The Your Virtual Friend Team</p>
        </div>
        <div class="footer">
            &copy; 2023 Your Virtual Friend. All rights reserved.
        </div>
    </div>
</body>
</html>
EOT;

                    if ($mail->send()) {
                        // Redirect to a confirmation page
                        header("Location: login.html");
                        exit;
                    } else {
                        echo "Error sending email: {$mail->ErrorInfo}";
                    }
                } catch (Exception $e) {
                    echo "Error sending email: {$e->getMessage()}";
                }
            } else {
                echo "Error updating activation token: " . $conn->error;
            }
        } else {
            echo "Error inserting user data: " . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>
