<?php
session_start();

$host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "users";

$conn = new mysqli($host, $db_username, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve submitted form data
    $loginusername = $_POST['login_username'];
    $loginpassword = $_POST['login_password'];

    // Input validation
    if (!filter_var($loginusername, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format.");
    }

    // Sanitize the input data to prevent SQL injection
    $loginusername = $conn->real_escape_string($loginusername);

    $checkLoginQuery = "SELECT * FROM users WHERE email = '$loginusername'";
    $result = $conn->query($checkLoginQuery);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        if (password_verify($loginpassword, $hashedPassword)) {
            // Successful login
            $_SESSION['username'] = $loginusername;
            echo "<script>alert('Login successful.'); window.location.href = 'chat.html';</script>";
            exit;
        } else {
            // Invalid password
            echo "<script>alert('Invalid username or password.'); window.location.href = 'login.html';</script>";
            exit;
        }
    } else {
        // Invalid username
        echo "<script>alert('Invalid username or password.'); window.location.href = 'login.html';</script>";
        exit;
    }
}

$conn->close();
?>
