<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST["username"];
    $email = $_POST["email"];
    $comments = $_POST["comments"];

    // Email settings
    $recipientEmail = "salonthapa511@gmail.com"; // Replace with your recipient email address (same as registration)
    $subject = "Contact Form Submission from Your Virtual Friend";
    $message = "Username: $username\nEmail: $email\nComments:\n$comments";

    $mail = new PHPMailer();
    try {
        // SMTP configuration (same as register.php)
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Your SMTP server
        $mail->SMTPAuth = true; // Enable SMTP authentication
        $mail->Username = 'salonthapa511@gmail.com'; // Your SMTP username
        $mail->Password = 'pxfifsbmejregmwo'; // Your SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
        $mail->Port = 587; // TCP port to connect to

        $mail->setFrom($email, $username);
        $mail->addAddress($recipientEmail);
        $mail->isHTML(false);

        $mail->Subject = $subject;
        $mail->Body = $message;

        if ($mail->send()) {
        
            echo "<script>alert('Thank you for contacting us, $username! Your message has been sent successfully.'); window.location.href = 'contact.html';</script>";
            
        } else {
            
            echo "<script>alert('Sorry, there was an error sending your message. Please try again later.'); window.location.href = 'contact.html';</script>";
        }
    } catch (Exception $e) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    }
} else {
    // Redirect to the contact page if accessed directly
    header("Location: contact.html");
    exit;
}
?>
